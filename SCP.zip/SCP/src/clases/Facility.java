package clases;

public class Facility {
	private String facility_id;
	private String facility_name;
	private int facility_level;
	
	public String getFacility_id() {
		return facility_id;
	}
	public void setFacility_id(String facility_id) {
		this.facility_id = facility_id;
	}
	public String getFacility_name() {
		return facility_name;
	}
	public void setFacility_name(String facility_name) {
		this.facility_name = facility_name;
	}
	public int getFacility_level() {
		return facility_level;
	}
	public void setFacility_level(int facility_level) {
		this.facility_level = facility_level;
	}
}
