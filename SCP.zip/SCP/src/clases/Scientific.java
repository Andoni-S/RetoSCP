package clases;

import controller.ScientificController;

public class Scientific extends Worker implements ScientificController{

	/*@Override
	public void logIn() {
		// TODO Auto-generated method stub
		
	}*/

	@Override
	public void showAsignedSCP() {
		
		
	}

	@Override
	public void modifySCP() {
		
		
	}

}
