package acs;

public enum Disruption {
	DARK, VLAM, KENEQ, EKHI, AMIDA;
}
