package acs;

public enum Containment {
	SAFE, EUCLID, KETER, NEUTRALIZATED, PENDING, EXPLAINED, ESOTERIC;
}
