package acs;

public enum SecondaryC {

APOLLYON,ARCHON,CERNUNNOS,HIEMAL,TIAMAT,TICONDEROGA,THAUMIEL;

}
