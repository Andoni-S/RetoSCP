package exceptions;

public class CreateException {

}
