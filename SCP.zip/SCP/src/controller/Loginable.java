package controller;

public interface Loginable {

	boolean logIn(String usernameUsuario, String passwordUsuario);
}
