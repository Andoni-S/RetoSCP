package controller;

import clases.Agent;
import clases.Facility;

public interface AgentController {

	Facility showAsignedFacility(String idWorker);
}
