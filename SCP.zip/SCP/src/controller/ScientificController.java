package controller;

public interface ScientificController {

	void showAsignedSCP();
	void modifySCP();
	
}
