package main;

public class Factory {

}
