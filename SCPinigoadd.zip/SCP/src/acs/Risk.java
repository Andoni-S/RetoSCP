package acs;

public enum Risk {
	NOTICE, CAUTION, WARNING, DANGER, CRITICAL;
}
