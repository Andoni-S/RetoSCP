package acs;

public enum Discruption {
	DARK, VLAM, KENEQ, EKHI, AMIDA;
}
