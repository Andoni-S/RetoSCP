package acs;

public enum Continent {
	EUROPA,AFRICA,AMERICA,ASIA,OCEANIA,ANTARTIDA;
}
