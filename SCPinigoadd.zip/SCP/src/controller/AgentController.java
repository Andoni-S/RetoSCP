package controller;

import clases.Facility;

public interface AgentController {
	
	Facility showAsignedFacility(String idWorker);
}
