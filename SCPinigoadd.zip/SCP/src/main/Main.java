package main;

import view.LoginWindow;

public class Main {

	public static void main(String[] args) {
		LoginWindow vMain = new LoginWindow();
		vMain.setVisible(true);
	}
	
}